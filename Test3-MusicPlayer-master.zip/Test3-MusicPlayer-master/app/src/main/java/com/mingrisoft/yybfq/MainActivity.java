package com.mingrisoft.yybfq;


import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;


public class MainActivity extends Activity {
    private MediaPlayer mp;//mediaPlayer对象
    private Button play,pause,stop,prev,next,shunxu,contentUpdate,suiji;//播放 暂停/继续 停止 按钮
    private TextView hint;//显示当前播放状态
    private boolean isPause=false;//是否暂停
    private SeekBar seekBar;
    private int i=0;
    private int[] misicPath=new int[]{R.raw.prev,R.raw.music,R.raw.next};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        play=(Button) findViewById(R.id.play);
        pause=(Button) findViewById(R.id.pause);
        stop=(Button) findViewById(R.id.stop);
        prev=(Button)findViewById(R.id.previous);
        next=(Button)findViewById(R.id.next);
        suiji=(Button)findViewById(R.id.suiji);
        shunxu=(Button)findViewById(R.id.shunxu);
        seekBar=(SeekBar)findViewById(R.id.seekbar);
        hint=(TextView) findViewById(R.id.text1);
        hint.setTextSize(20);
        mp=MediaPlayer.create(MainActivity.this,R.raw.music);//创建mediaplayer对象
        mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer arg0) {
                play();//重新开始播放
            }
        });
        prev.setOnClickListener(new View.OnClickListener(){
            @Override
            public void  onClick(View v){
                try{
                    mp.reset();
                    mp=MediaPlayer.create(MainActivity.this, R.raw.prev);//重新设置要播放的音频
                    mp.start();//开始播放
                    hint.setText("正在播放音频...");
                    play.setEnabled(false);
                    pause.setEnabled(true);
                    stop.setEnabled(true);
                }catch(Exception e){
                    e.printStackTrace();//输出异常信息
                }
                if(isPause){
                    pause.setText("暂停");
                    isPause=false;
                }
            }
        });
        next.setOnClickListener(new View.OnClickListener(){
            @Override
            public void  onClick(View v){
                try{
                    mp.reset();
                    mp=MediaPlayer.create(MainActivity.this, R.raw.next);//重新设置要播放的音频
                    mp.start();//开始播放
                    hint.setText("正在播放音频...");
                    play.setEnabled(false);
                    pause.setEnabled(true);
                    stop.setEnabled(true);
                }catch(Exception e){
                    e.printStackTrace();//输出异常信息
                }
                if(isPause){
                    pause.setText("暂停");
                    isPause=false;
                }
            }
        });
        play.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                play();
                if(isPause){
                    pause.setText("暂停");
                    isPause=false;
                }
            }
        });
        pause.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                if(mp.isPlaying()&&!isPause){
                    mp.pause();
                    isPause=true;
                    pause.setText("继续");
                    hint.setText("暂停播放音频...");
                    play.setEnabled(true);
                }else{
                    mp.start();
                    pause.setText("暂停");
                    hint.setText("继续播放音频...");
                    isPause=false;
                    play.setEnabled(false);
                }
            }
        });

        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mp.stop();
                hint.setText("停止播放音频...");
                pause.setEnabled(false);
                stop.setEnabled(false);
                play.setEnabled(true);
            }
        });
        shunxu.setOnClickListener(new View.OnClickListener(){
            @Override
            public void  onClick(View v){
                    try {
                            mp.reset();
                            mp = MediaPlayer.create(MainActivity.this, misicPath[i]);//重新设置要播放的音频
                            mp.start();//开始播放
                            hint.setText("正在播放音频...");
                            play.setEnabled(false);
                            pause.setEnabled(true);
                            stop.setEnabled(true);
                            i++;
                    } catch (Exception e) {
                        e.printStackTrace();//输出异常信息
                    }
                    if (isPause) {
                        pause.setText("暂停");
                        isPause = false;
                    }
            }
        });
        suiji.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                try {
                    mp.reset();
                    mp = MediaPlayer.create(MainActivity.this, misicPath[(int)Math.random()*2]);//重新设置要播放的音频
                    mp.start();//开始播放
                    hint.setText("正在播放音频...");
                    play.setEnabled(false);
                    pause.setEnabled(true);
                    stop.setEnabled(true);

                } catch (Exception e) {
                    e.printStackTrace();//输出异常信息
                }
                if (isPause) {
                    pause.setText("暂停");
                    isPause = false;
                }
            }
        });
    }

    private void play(){
        try{
            mp.reset();
            mp=MediaPlayer.create(MainActivity.this, R.raw.music);//重新设置要播放的音频
            mp.start();//开始播放
            hint.setText("正在播放音频...");
            play.setEnabled(false);
            pause.setEnabled(true);
            stop.setEnabled(true);
        }catch(Exception e){
            e.printStackTrace();//输出异常信息
        }
    }
    protected void onDestroy() {
        // TODO Auto-generated method stub
        if(mp.isPlaying()){
            mp.stop();
        }
        mp.release();//释放资源
        super.onDestroy();
    }


}
